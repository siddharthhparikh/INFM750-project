from ..utils.data_utils import *
import warnings

warnings.warn('data_utils has been moved to keras.utils.data_utils.')
